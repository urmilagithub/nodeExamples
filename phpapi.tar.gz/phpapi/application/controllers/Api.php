<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
require(APPPATH.'/libraries/REST_Controller.php');
class Api extends REST_Controller
{
 
    public function __construct() {
        parent::__construct();
        $this->load->model('user_model');
    }    

    public function user_get(){
        $r = $this->user_model->read();
        if($r){
            $this->response($r, 200); 
            exit;
        } 
        else{
            $this->response("Something went wrong", 404);
            exit;
        }
       
    }

    public function user_put(){
        $id = $this->uri->segment(3);
        
        if(!$id){
            $this->response("Parameter missing", 404);
        }

        $data = array('name' => $this->input->get('name'),
        'pass' => $this->input->get('pass'),
        'type' => $this->input->get('type')
        );

        $r = $this->user_model->update($id,$data);
        
        if($r)
        {
            $this->response("Data is updated successfully", 200);
        } 
        else
        {
            $this->response("Error has occurred", 400);
        }
    }

    public function user_post(){

        $name = $this->input->post('name');
        $pass = $this->input->post('pass');
        $type = $this->input->post('type');
        if($name == "" || $pass == "" || $type == ""){
            $this->response("Enter complete User information to save", 400);
        }else{
            $data = array(
                'name' => $name,
                'pass' => $pass,
                'type' => $type
            );
            $r = $this->user_model->insert($data);
            $this->response("Record Inserted Succesfully", 200);
        } 
    }
    
    public function user_delete(){
        $id = $this->uri->segment(3);
     
        if(!$id){
            $this->response("Parameter missing", 404);
        } 
        $result = $this->user_model->delete($id);        
        if($result)
        {
            $this->response("Record Deleted Successfully", 200);
        } 
        else
        {
            $this->response("Error has occurred", 400);
        }
    }  
}