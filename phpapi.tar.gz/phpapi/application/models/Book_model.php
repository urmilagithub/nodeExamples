<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Book_model extends CI_Model
{

	var $table = 'books';

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function get_all_books()
	{
	$this->db->from('books');
	$query=$this->db->get();
	return $query->result();
	}

	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('book_id',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function book_add($data)
	{
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	public function book_update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_by_id($id)
	{
		$this->db->where('book_id', $id);
		$this->db->delete($this->table);
	}


	//API Call functions started here.
	 //API call - get a book record by isbn
	public function getbookbyisbn($isbn)
	{ 
		$this->db->select('id, name, price, author, category, language, ISBN, publish_date');
		$this->db->from('tbl_books');
		$this->db->where('isbn',$isbn);
		$query = $this->db->get();
		if($query->num_rows() == 1)
		{
			return $query->result_array();
		}
		else
		{
			return 0;
		}
    }

	//API call - get all books record
	public function getallbooks()
	{   
		$this->db->select('id, name, price, author, category, language, ISBN, publish_date');
		$this->db->from('tbl_books');
		$this->db->order_by("id", "desc"); 
		$query = $this->db->get();
		if($query->num_rows() > 0){
		return $query->result_array();
		}else{
		return 0;
		}
	}

	//API call - delete a book record
	public function delete($id)
	{
		$this->db->where('id', $id);
		if($this->db->delete('tbl_books')){
		return true;
		}else{
		return false;
		}
	}

	//API call - add new book record
	public function add($data)
	{
		if($this->db->insert('tbl_books', $data)){
			return true;
		}else{
			return false;
		}
	}
	
	//API call - update a book record
	public function update($id, $data)
	{
		$this->db->where('id', $id);
		if($this->db->update('tbl_books', $data)){
		return true;
		}else{
		return false;
		}
	}
}
